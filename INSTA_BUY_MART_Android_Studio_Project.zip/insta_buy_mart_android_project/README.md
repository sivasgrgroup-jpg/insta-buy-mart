# INSTA BUY MART Android Studio starter project

This is an Android Studio project wrapper around the current red/black Tamil-English storefront prototype.

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this project folder in Android Studio.
3. Allow Gradle sync to finish (internet is needed to download Android Gradle Plugin).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Current limitations
This is a UI prototype packaged in a basic Android WebView shell. It is NOT a production marketplace:
- No real phone OTP authentication or Firebase project configured.
- No backend/database, customer accounts, supplier accounts, or owner-only admin authorization.
- No real orders, inventory sync, shipping, refunds, or payment processing.
- UPI/online payment options are demo labels only; no money can be collected.
- Sample products and seller names are demonstration data.

Before public launch, connect a secure backend, configure Firebase Phone Auth and authorized domains, implement server-side role checks, integrate a payment gateway with server-side verification/webhooks, and complete privacy/security testing.
